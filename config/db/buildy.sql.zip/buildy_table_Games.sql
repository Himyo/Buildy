
--
-- Dumping data for table `Games`
--

INSERT INTO `Games` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'MAGIC: THE GATHERING', NULL, NULL);
