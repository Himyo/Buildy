
--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`id`, `lastname`, `firstname`, `owner`, `email`, `password`, `status`, `role`, `token`, `photo_id`) VALUES
(1, 'YY', 'Y', NULL, 'y@g.fr', '$2y$10$Uk5wGHzmRBmCUngmbQJ2IenZMQg5GVqs9CuRMIp0jqeXydd8iqiWq', 0, 1, '$2y$10$ip17SpkIfHeBi69IN5AI8uWcuh7dQx8lfN6HZrI93e8n9LIukkDNG', NULL),
(2, 'YY', 'Y', NULL, 'y@g.fr', '$2y$10$YzeKCmBMhzcKNHxlVGlTdOFpQ24vcsM/63DbWbehbIiyGQZqyzepS', 0, 1, '$2y$10$xlaCzGprl.En8he.BeC0..eP6sOUJoPBgGH8462JxzHI0WYUsu8fG', NULL),
(3, 'TTT', 'Ttt', NULL, 't@g.com', '$2y$10$6X/VOWuLZVIzIJePO7CANufNHq.rTW5aaeIXYRn8K4mzI20UUyTBa', 0, 1, '$2y$10$Aw/lp.gEsFvZP0fIMKYKMeKdamLK8Ljqws7qBNhVeoK9JhRpKiqq6', NULL),
(4, 'TTT', 'Ttt', NULL, 't@g.com', '$2y$10$92oo.oTa7lE3tJ.BRkluhudxrrL7S1H/Jh0OrQNuZU4kZsO.TwerC', 0, 1, '$2y$10$bXtRn9LRmcehscbzyzDlyepFy8mBaUyn4sEVXr2tNkgdEqzkbnfni', NULL),
(5, 'TTT', 'Ttt', NULL, 't@g.com', '$2y$10$zeLboTlQbKmx3fuKCft91OJ9CzQ7MqkzV5nCQ1sDXB19Jt7K1fl4C', 0, 1, '$2y$10$725s8rwdUlqsInBDRJIWTuGKxHvWK107WBh2SguttmKzlAaJAEXBu', NULL);
